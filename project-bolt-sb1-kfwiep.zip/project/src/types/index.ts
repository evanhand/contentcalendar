export interface Hook {
  type: string;
  text: string;
  score: number;
}

export interface ContentDay {
  day: string;
  overallIdea: string;
  contentType: string;
  talkingPoints: string[];
  hooks: string[];
  additionalNotes: string;
}

export interface ContentWeek {
  weekNumber: number;
  days: ContentDay[];
}

export interface ContentTemplate {
  niche: string;
  targetAudience: string;
  businessDescription: string;
  weeks: ContentWeek[];
}

export interface UserContext {
  niche: string;
  businessDescription: string;
  targetAudience: string;
  contentGoals: string;
  uniqueValue: string;
}